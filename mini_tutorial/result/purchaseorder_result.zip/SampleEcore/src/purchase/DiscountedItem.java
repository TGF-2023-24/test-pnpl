/**
 */
package purchase;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Discounted Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link purchase.DiscountedItem#getDiscount <em>Discount</em>}</li>
 * </ul>
 *
 * @see purchase.PurchasePackage#getDiscountedItem()
 * @model
 * @generated
 */
public interface DiscountedItem extends Item {
	/**
	 * Returns the value of the '<em><b>Discount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Discount</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discount</em>' attribute.
	 * @see #setDiscount(float)
	 * @see purchase.PurchasePackage#getDiscountedItem_Discount()
	 * @model
	 * @generated
	 */
	float getDiscount();

	/**
	 * Sets the value of the '{@link purchase.DiscountedItem#getDiscount <em>Discount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discount</em>' attribute.
	 * @see #getDiscount()
	 * @generated
	 */
	void setDiscount(float value);

} // DiscountedItem
